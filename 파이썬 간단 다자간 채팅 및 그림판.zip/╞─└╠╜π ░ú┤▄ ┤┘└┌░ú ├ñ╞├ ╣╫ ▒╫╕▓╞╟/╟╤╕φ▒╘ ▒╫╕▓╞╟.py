import tkinter as tk
from tkinter import colorchooser, filedialog
from PIL import Image, ImageDraw, ImageTk

class PaintApp:
    def __init__(self, root):
        self.root = root
        self.root.title("그림판 한명규")
        self.root.geometry("800x600")

        self.canvas = tk.Canvas(root, bg='white', width=800, height=600)
        self.canvas.pack(expand=tk.YES, fill=tk.BOTH)

        self.color = 'black'
        self.pen_width = 5

        self.create_menu()
        self.setup_canvas()

        self.image = Image.new('RGB', (800, 600), 'white')
        self.draw = ImageDraw.Draw(self.image)

    def create_menu(self):
        menu = tk.Menu(self.root)
        self.root.config(menu=menu)
        
        file_menu = tk.Menu(menu, tearoff=0)
        menu.add_cascade(label="파일", menu=file_menu)
        file_menu.add_command(label="새 파일", command=self.new_file)
        file_menu.add_command(label="열기", command=self.open_file)
        file_menu.add_command(label="저장", command=self.save_file)
        file_menu.add_command(label="종료", command=self.root.quit)

        edit_menu = tk.Menu(menu, tearoff=0)
        menu.add_cascade(label="편집", menu=edit_menu)
        edit_menu.add_command(label="색상", command=self.choose_color)
        edit_menu.add_command(label="붓 크기", command=self.set_pen_width)

    def setup_canvas(self):
        self.canvas.bind('<Button-1>', self.on_mouse_down)
        self.canvas.bind('<B1-Motion>', self.on_mouse_drag)
        self.canvas.bind('<ButtonRelease-1>', self.on_mouse_up)
        self.last_x, self.last_y = None, None

    def on_mouse_down(self, event):
        self.last_x, self.last_y = event.x, event.y

    def on_mouse_drag(self, event):
        if self.last_x and self.last_y:
            x, y = event.x, event.y
            self.canvas.create_line(self.last_x, self.last_y, x, y, fill=self.color, width=self.pen_width)
            self.draw.line([self.last_x, self.last_y, x, y], fill=self.color, width=self.pen_width)
            self.last_x, self.last_y = x, y

    def on_mouse_up(self, event):
        self.last_x, self.last_y = None, None

    def choose_color(self):
        color = colorchooser.askcolor()[1]
        if color:
            self.color = color

    def set_pen_width(self):
        width = tk.simpledialog.askinteger("붓 크기", "붓 크기를 입력하세요:", initialvalue=self.pen_width, minvalue=1)
        if width:
            self.pen_width = width

    def new_file(self):
        self.canvas.delete('all')
        self.image = Image.new('RGB', (800, 600), 'white')
        self.draw = ImageDraw.Draw(self.image)

    def open_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("이미지 파일", "*.png")])
        if file_path:
            self.image = Image.open(file_path)
            self.draw = ImageDraw.Draw(self.image)
            self.display_image()

    def save_file(self):
        file_path = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG 파일", "*.png")])
        if file_path:
            self.image.save(file_path)

    def display_image(self):
        self.canvas.delete('all')
        self.tk_image = ImageTk.PhotoImage(self.image)
        self.canvas.create_image(0, 0, anchor=tk.NW, image=self.tk_image)

if __name__ == "__main__":
    root = tk.Tk()
    app = PaintApp(root)
    root.mainloop()
