import tkinter as tk
from tkinter import filedialog, messagebox

class Notepad:
    def __init__(self, root):
        self.root = root
        self.root.title("메모장한명규")
        self.root.geometry("800x800")

        self.text = tk.Text(root, wrap='word')
        self.text.pack(expand='yes', fill='both')

        self.menu = tk.Menu(root)
        self.root.config(menu=self.menu)

        self.file_menu = tk.Menu(self.menu, tearoff=0)
        self.menu.add_cascade(label="파일", menu=self.file_menu)
        self.file_menu.add_command(label="새 파일", command=self.new_file)
        self.file_menu.add_command(label="열기", command=self.open_file)
        self.file_menu.add_command(label="저장", command=self.save_file)
        self.file_menu.add_command(label="종료", command=self.exit_app)

    def new_file(self):
        if self.confirm_unsaved_changes():
            self.text.delete(1.0, tk.END)

    def open_file(self):
        if not self.confirm_unsaved_changes():
            return

        file_path = filedialog.askopenfilename(defaultextension=".txt", filetypes=[("텍스트 파일", "*.txt"), ("모든 파일", "*.*")])
        if file_path:
            with open(file_path, 'r', encoding='utf-8') as file:
                content = file.read()
                self.text.delete(1.0, tk.END)
                self.text.insert(tk.END, content)

    def save_file(self):
        file_path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("텍스트 파일", "*.txt"), ("모든 파일", "*.*")])
        if file_path:
            with open(file_path, 'w', encoding='utf-8') as file:
                content = self.text.get(1.0, tk.END)
                file.write(content)
    
    def exit_app(self):
        if self.confirm_unsaved_changes():
            self.root.quit()

    def confirm_unsaved_changes(self):
        if self.text.edit_modified():
            response = messagebox.askyesnocancel("저장", "저장하지 않은 변경 사항이 있습니다. 저장하시겠습니까?")
            if response:
                self.save_file()
                return True
            elif response is False:
                return True
            else:
                return False
        return True

if __name__ == "__main__":
    root = tk.Tk()
    app = Notepad(root)
    root.mainloop()
